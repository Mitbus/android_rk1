package com.example.lab3

class Info(val header: String, val description: String) {
}